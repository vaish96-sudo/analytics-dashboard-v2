# SECURITY FIX SUMMARY — Northern Bird Analytics V2

**Date:** March 24, 2026  
**Scope:** All findings from security audit (C1-C3, H1-H3, M1-M6, L1-L3)

---

## Files Modified

### API (Serverless Functions)
| File | Changes |
|------|---------|
| `api/claude.js` | **Rewritten** — session auth (C1), rate limiting (M1), model enforcement (M3), max_tokens cap (M2), usage logging (M6) |
| `api/lib/validateSession.js` | **New** — shared session validation helper |
| `api/auth/forgot-password.js` | Removed token console.logs (C2) |
| `api/auth/login.js` | Added rate limiting — 10 attempts / 5 min per IP (M1) |
| `api/fetch-external.js` | Complete SSRF blocklist — 169.254.169.254, ::1, 0.0.0.0, fd/fc ranges, protocol check (H3) |
| `api/google-sheets-data.js` | Error message sanitization — redacts Bearer tokens (M5) |
| `api/google-sheets-list.js` | Error message sanitization — redacts Bearer tokens (M5) |

### Frontend (src/)
| File | Changes |
|------|---------|
| `src/utils/claudeClient.js` | **New** — authenticated API wrapper (sends `feature` not `model`, attaches Bearer token) |
| `src/utils/aiService.js` | Feature-based calls, removed client model control, capped retries to 2 (M3, L3) |
| `src/context/AuthContext.jsx` | Removed DEV_MODE and all dev-bypass code paths (M4) |
| `src/context/DataContext.jsx` | Replaced `new Function()` with `safeMathEval()` recursive-descent parser (H2), console.logs removed (L1) |
| `src/lib/supabase.js` | Removed anon key console.log (C3) |
| `src/lib/projectService.js` | Console.logs removed (L1) |
| `src/components/CustomMetrics.jsx` | Uses `callClaudeAPI` with auth + feature (M3) |
| `src/components/AIRecommendations.jsx` | Uses `callClaudeAPI` with auth + feature (M3), console.logs removed |
| `src/components/AutoCharts.jsx` | Uses `callClaudeAPI` with auth + feature (M3), console.logs removed |
| `src/components/AIChartBuilder.jsx` | Uses `callClaudeAPI` with auth + feature (M3) |
| `src/components/AIInsights.jsx` | Console.logs removed (L1) |

### Database Migration
| File | Purpose |
|------|---------|
| `supabase_migration.sql` | `ai_usage_log` table (M6), RLS on all tables (H1), session cleanup function (L2), monthly spend view |

---

## Detailed Fix Summary

### CRITICAL
- **C1:** `/api/claude` now requires `Authorization: Bearer <session_token>` — unauthenticated requests get 401
- **C2:** Reset token `console.log` lines deleted, TODO comment left for email service integration
- **C3:** `console.log('KEY:', ...)` deleted from `supabase.js`

### HIGH
- **H1:** RLS enabled on all 7 tables + `ai_usage_log`. Anon key gets SELECT-only; all writes restricted to service key (server-side). See `supabase_migration.sql`
- **H2:** Both `new Function()` calls in `DataContext.jsx` replaced with `safeMathEval()` — a zero-dependency recursive-descent parser supporting `+ - * / ()` and decimals. No code execution possible
- **H3:** SSRF blocklist now covers: localhost, 127.0.0.1, ::1, 0.0.0.0, 192.168.x, 10.x, 172.16-31.x, 169.254.x (including 169.254.169.254 AWS metadata), fd00::/fc00::/fe80:: IPv6 ranges, and non-http(s) protocols

### MEDIUM
- **M1:** Rate limiting on `/api/claude` (20 req/min per user) and `/api/auth/login` (10 attempts/5 min per IP). In-memory with cleanup to prevent leaks
- **M2:** `max_tokens` capped at 4096 server-side: `Math.min(Number(max_tokens) || 1024, 4096)`
- **M3:** Server-side model mapping via `FEATURE_MODEL_MAP`. Client sends feature name (`ask_ai`, `insights`, `recommendations`, etc.), server resolves to model. All 6 frontend callers updated via `callClaudeAPI` helper
- **M4:** `DEV_MODE = import.meta.env.DEV` and both bypass code paths (signup without password hash, login without password check) fully removed
- **M5:** Error catch blocks in Google Sheets endpoints now redact Bearer tokens from error messages
- **M6:** New `ai_usage_log` table tracks: user_id, feature, model, input/output tokens, estimated cost. View `user_monthly_ai_spend` provides per-user monthly rollups

### LOW
- **L1:** All `console.log` calls removed from production code (DataContext, projectService, aiService, AutoCharts, AIInsights, AIRecommendations)
- **L2:** `cleanup_expired_sessions()` function created. Uncomment the `cron.schedule` line after enabling pg_cron in Supabase
- **L3:** Retry logic simplified: max 2 retries (down from 3+2 recursive fallback = 5 potential calls). No more recursive Opus→Sonnet doubling

---

## Deployment Steps

1. **Run the SQL migration** — Go to Supabase Dashboard → SQL Editor → paste and run `supabase_migration.sql`
2. **Deploy code** — Push the updated `api/` and `src/` to GitHub, Vercel will auto-deploy
3. **Verify auth works** — Test login, then test that `/api/claude` rejects unauthenticated requests
4. **Set Anthropic budget** — Go to Anthropic Console → set monthly spending limit
5. **Enable pg_cron** (optional) — Uncomment the cron line in the migration to auto-clean expired sessions
6. **Monitor** — Check `ai_usage_log` table and `user_monthly_ai_spend` view for cost tracking

---

## What Wasn't Changed (Preserved)

- PBKDF2 password hashing (100K iterations, random salt) ✓
- password_hash stripping from user objects ✓
- 32-byte crypto session tokens ✓
- Reset token 1-hour expiry + session invalidation ✓
- Existing formula regex validation (still runs before safeMathEval) ✓
- All UI functionality and user-facing features ✓
