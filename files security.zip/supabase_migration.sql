-- ============================================================================
-- NORTHERN BIRD ANALYTICS V2 — SECURITY FIX MIGRATION
-- Run this in Supabase SQL Editor (Dashboard → SQL Editor → New Query)
-- ============================================================================

-- ═══════════════════════════════════════════════════════════════════
-- M6: AI USAGE TRACKING TABLE
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS ai_usage_log (
  id            uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  feature       text NOT NULL,              -- 'ask_ai', 'insights', 'recommendations', etc.
  model         text NOT NULL,              -- 'claude-sonnet-4-20250514', 'claude-opus-4-20250514'
  input_tokens  integer NOT NULL DEFAULT 0,
  output_tokens integer NOT NULL DEFAULT 0,
  estimated_cost_usd numeric(10,6) NOT NULL DEFAULT 0,
  created_at    timestamptz DEFAULT now()
);

-- Index for per-user cost queries and daily/monthly rollups
CREATE INDEX IF NOT EXISTS idx_ai_usage_user_date ON ai_usage_log (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_usage_created ON ai_usage_log (created_at DESC);


-- ═══════════════════════════════════════════════════════════════════
-- H1: ROW LEVEL SECURITY (RLS)
-- ═══════════════════════════════════════════════════════════════════
-- NOTE: This app uses CUSTOM auth (not Supabase Auth), so we cannot use
-- auth.uid(). Instead, RLS is enabled to block anonymous/direct access,
-- and the server uses the SERVICE_KEY which bypasses RLS. This means:
--   - Browser client (anon key) → RLS blocks sensitive writes
--   - Server (service key) → RLS bypassed, full access
--
-- If you migrate to Supabase Auth in the future, replace these policies
-- with auth.uid()-based policies for true per-user row isolation.

-- === users ===
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Allow anon key to read own profile (for background session validation)
-- Since we can't use auth.uid(), we allow SELECT but block mutations
CREATE POLICY "users_select_own" ON users
  FOR SELECT USING (true);
  -- The anon key can read, but only the server (service key) can write

CREATE POLICY "users_no_anon_insert" ON users
  FOR INSERT WITH CHECK (false);

CREATE POLICY "users_no_anon_delete" ON users
  FOR DELETE USING (false);

-- Allow update only from service key (server-side)
CREATE POLICY "users_no_anon_update" ON users
  FOR UPDATE USING (false);


-- === sessions ===
ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;

-- Anon key needs to read sessions for background validation
CREATE POLICY "sessions_select" ON sessions
  FOR SELECT USING (true);

-- Only server (service key) should create/delete sessions
CREATE POLICY "sessions_no_anon_insert" ON sessions
  FOR INSERT WITH CHECK (false);

CREATE POLICY "sessions_no_anon_delete" ON sessions
  FOR DELETE USING (false);


-- === projects ===
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "projects_select" ON projects
  FOR SELECT USING (true);

CREATE POLICY "projects_no_anon_insert" ON projects
  FOR INSERT WITH CHECK (false);

CREATE POLICY "projects_no_anon_update" ON projects
  FOR UPDATE USING (false);

CREATE POLICY "projects_no_anon_delete" ON projects
  FOR DELETE USING (false);


-- === datasets ===
ALTER TABLE datasets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "datasets_select" ON datasets
  FOR SELECT USING (true);

CREATE POLICY "datasets_no_anon_insert" ON datasets
  FOR INSERT WITH CHECK (false);

CREATE POLICY "datasets_no_anon_update" ON datasets
  FOR UPDATE USING (false);

CREATE POLICY "datasets_no_anon_delete" ON datasets
  FOR DELETE USING (false);


-- === dashboard_states ===
ALTER TABLE dashboard_states ENABLE ROW LEVEL SECURITY;

CREATE POLICY "dashboard_states_select" ON dashboard_states
  FOR SELECT USING (true);

CREATE POLICY "dashboard_states_no_anon_insert" ON dashboard_states
  FOR INSERT WITH CHECK (false);

CREATE POLICY "dashboard_states_no_anon_update" ON dashboard_states
  FOR UPDATE USING (false);

CREATE POLICY "dashboard_states_no_anon_delete" ON dashboard_states
  FOR DELETE USING (false);


-- === conversations ===
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "conversations_select" ON conversations
  FOR SELECT USING (true);

CREATE POLICY "conversations_no_anon_insert" ON conversations
  FOR INSERT WITH CHECK (false);

CREATE POLICY "conversations_no_anon_update" ON conversations
  FOR UPDATE USING (false);

CREATE POLICY "conversations_no_anon_delete" ON conversations
  FOR DELETE USING (false);


-- === messages ===
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "messages_select" ON messages
  FOR SELECT USING (true);

CREATE POLICY "messages_no_anon_insert" ON messages
  FOR INSERT WITH CHECK (false);

CREATE POLICY "messages_no_anon_update" ON messages
  FOR UPDATE USING (false);

CREATE POLICY "messages_no_anon_delete" ON messages
  FOR DELETE USING (false);


-- === ai_usage_log ===
ALTER TABLE ai_usage_log ENABLE ROW LEVEL SECURITY;

-- Only server (service key) writes usage logs
CREATE POLICY "ai_usage_log_no_anon_insert" ON ai_usage_log
  FOR INSERT WITH CHECK (false);

CREATE POLICY "ai_usage_log_select" ON ai_usage_log
  FOR SELECT USING (true);


-- ═══════════════════════════════════════════════════════════════════
-- L2: SESSION CLEANUP (run periodically)
-- ═══════════════════════════════════════════════════════════════════
-- Option A: Run this manually or via Supabase cron extension (pg_cron)
-- Option B: Create a Supabase Edge Function on a schedule

-- Enable pg_cron if not already enabled:
-- CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Create cleanup function
CREATE OR REPLACE FUNCTION cleanup_expired_sessions()
RETURNS integer
LANGUAGE plpgsql
AS $$
DECLARE
  deleted_count integer;
BEGIN
  DELETE FROM sessions WHERE expires_at < now();
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$;

-- Schedule daily cleanup at 3 AM UTC (uncomment after enabling pg_cron):
-- SELECT cron.schedule('cleanup-expired-sessions', '0 3 * * *', 'SELECT cleanup_expired_sessions()');


-- ═══════════════════════════════════════════════════════════════════
-- USAGE HELPER VIEW: Per-user monthly AI spend
-- ═══════════════════════════════════════════════════════════════════

CREATE OR REPLACE VIEW user_monthly_ai_spend AS
SELECT
  user_id,
  date_trunc('month', created_at) AS month,
  count(*) AS total_calls,
  sum(input_tokens) AS total_input_tokens,
  sum(output_tokens) AS total_output_tokens,
  sum(estimated_cost_usd) AS total_cost_usd,
  count(*) FILTER (WHERE feature = 'insights') AS insight_calls,
  count(*) FILTER (WHERE feature = 'recommendations') AS recommendation_calls,
  count(*) FILTER (WHERE feature = 'ask_ai') AS ask_ai_calls
FROM ai_usage_log
GROUP BY user_id, date_trunc('month', created_at);
