# MEURIS ANALYTICS — HANDOFF V3 FOR SECURITY SESSION

## CRITICAL: Upload this file + both zip files (src.zip, api.zip) to the next chat

## Current State (Everything Working)
1. Passwordless login via Resend OTP codes
2. 3-tier system: Free / Pro $19 / Enterprise (agency internally)
3. Google Sheets connector (OAuth → pick sheet → import → column tagger → dashboard)
4. AI: Ask questions, insights, recommendations (with blurred preview + usage badges)
5. AI Chart Builder with click-to-filter
6. Project sharing (client-level + project-level) with portal-based menus
7. Team seats, invites, pending acceptance
8. White-label (Enterprise), custom AI playbook (Enterprise)
9. Drag-and-drop widgets, KPI cards, auto-charts
10. Report builder, data table, export (PDF/Word/Excel)
11. Onboarding overlay
12. Smart number formatting

## SECURITY VULNERABILITY (Fix in next session)
Frontend uses Supabase anon key with open RLS (USING true). Anyone can copy the anon key from DevTools and read/write/delete ALL data for ALL users.

## CHOSEN APPROACH: Option B — Server-side API layer
Keep the existing auth system (it works). Move ALL Supabase operations behind Vercel API routes with session validation. Remove anon key from frontend.

### Why NOT Option A (Supabase Auth migration):
- Would require ripping out the working passwordless login system
- Risk of breaking auth for existing accounts
- Supabase Auth OTP uses its own email system (conflicts with Resend)
- The custom session system works fine — it just needs to be the ONLY way to access data

### The Plan (execute in order):

#### Step 1: Build the secure API client (frontend)
Create `src/lib/api.js` — a fetch wrapper that:
- Reads session token from localStorage (nb_session_token)
- Adds `Authorization: Bearer <token>` to every request
- Adds `Content-Type: application/json`
- Handles 401 (redirect to login), 429 (rate limit), errors
- Provides get(), post(), patch(), del() methods

#### Step 2: Build API routes for ALL data operations
Each route: validates session via validateSession.js, checks ownership, uses service key.

CRITICAL: Build these ONE AT A TIME and test each before moving to the next.

Routes needed (17 total):
```
api/data/projects.js          — GET (list mine), POST (create)
api/data/project/[id].js      — GET (single + datasets), PATCH (rename), DELETE
api/data/datasets.js           — POST (create with storage upload)
api/data/dataset/[id].js       — GET (with raw data), DELETE
api/data/dashboard-state.js    — GET ?dataset_id=X, PATCH (update state)
api/data/conversations.js      — GET ?project_id=X, POST (create)
api/data/conversation/[id].js  — GET, PATCH (rename), DELETE
api/data/messages.js           — GET ?conversation_id=X, POST (add message)
api/data/user-profile.js       — GET (my profile), PATCH (update)
api/data/teams.js              — GET (my team), POST (create team)
api/data/team-members.js       — GET ?team_id=X, POST (invite), PATCH (role), DELETE (remove)
api/data/client-access.js      — POST (grant), DELETE (revoke)
api/data/project-access.js     — POST (grant), DELETE (revoke)
api/data/shared-projects.js    — GET (projects shared with me)
api/data/scheduled-reports.js  — GET, POST, PATCH, DELETE
api/data/upload-logo.js        — POST (multipart, upload to storage)
api/data/all-conversations.js  — GET (cross-project, for home screen)
api/data/all-insights.js       — GET (cross-project, for home screen)
```

Ownership checks per route:
- projects: user_id must match session userId
- datasets: project.user_id must match (join through project)
- dashboard_states: dataset.project.user_id must match
- conversations: project.user_id must match
- messages: conversation.project.user_id must match
- teams: owner_id must match OR user is active team_member
- sharing: must be team owner to grant/revoke
- shared-projects: only returns projects explicitly shared with this user

#### Step 3: Refactor frontend files (one at a time)
Replace `supabase.from(...)` calls with `api.get/post/patch/del(...)` calls.

Files to refactor (in this order — least risky first):
1. src/lib/projectService.js — THE BIG ONE. All CRUD ops.
2. src/context/ProjectContext.jsx — loads projects, shared projects
3. src/context/TierContext.jsx — reads/writes user_profiles
4. src/context/AuthContext.jsx — session validation (keep logout via API)
5. src/components/TeamManager.jsx — team CRUD
6. src/components/ClientShareMenu.jsx — client_access queries
7. src/components/ProjectShareMenu.jsx — project_access queries
8. src/components/PendingInvites.jsx — team_members updates
9. src/components/ScheduledReports.jsx — scheduled_reports CRUD
10. src/components/HomeScreen.jsx — teams query, project renames
11. src/components/UserProfile.jsx — logo upload

#### Step 4: Remove anon key
- Delete VITE_SUPABASE_ANON_KEY from Vercel env vars
- Delete VITE_SUPABASE_URL from Vercel env vars (frontend no longer needs it)
- Remove or gut src/lib/supabase.js (may keep for storage public URLs only)

#### Step 5: Add CSRF + hardening
- All POST/PATCH/DELETE API routes check Origin header
- Rate limiting on data API routes (not just Claude)
- Add security headers in vercel.json (CSP, X-Frame-Options, etc.)

#### Step 6: Tighten RLS as defense-in-depth
Even though frontend won't use anon key, add restrictive RLS:
- service_role bypasses RLS (API routes use this)
- anon role gets DENIED on all tables
- If someone somehow gets the anon key, they can't do anything

### IMPORTANT: What NOT to change
- The auth flow (login, signup, verify-code, send-code) — already server-side, already secure
- The Claude API route — already server-side with session validation
- The Google Sheets routes — already server-side
- The fetch-external route — already server-side with SSRF protection

## Live App
- URL: https://analytics-dashboard-v2-zeta.vercel.app
- GitHub: github.com/vaish96-sudo/analytics-dashboard-v2 (branch: master)
- Stack: React 18, Vite, Tailwind CSS, Recharts, Supabase Pro, Anthropic API, Vercel Pro

## Supabase
- URL: https://sntaaixuewpsxuennqxe.supabase.co
- Tables: users, sessions, projects (has client_name column), datasets, dashboard_states, conversations, messages, user_profiles, teams, team_members, scheduled_reports, ai_usage_log, login_codes, client_access, project_access
- Storage: datasets bucket (gzipped JSON), logos bucket
- RLS: Currently OPEN — this is the vulnerability being fixed

## Environment Variables (Vercel)
ANTHROPIC_API_KEY, SUPABASE_URL, SUPABASE_SERVICE_KEY, VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY, RESEND_API_KEY, FROM_EMAIL, VITE_GOOGLE_CLIENT_ID, GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET

After refactor REMOVE: VITE_SUPABASE_ANON_KEY, VITE_SUPABASE_URL

## Pricing Tiers (in tierConfig.js)
- free: 1 project, 5K rows, 5 AI/mo, 1 insight, 0 recs (preview)
- pro: $19/mo, 10 projects, 500K rows, 100 AI/mo, 10 insights, 5 recs, exports, connectors
- agency (labeled "Enterprise"): unlimited, teams, white-label, playbook, custom pricing

## Testing Accounts
- Main: vaish96@gmail.com (agency tier — shows as "Enterprise")
- Dummy: vaish96+team1@gmail.com (free tier, team member with viewer role)
- Both in same team, both active in team_members

## Database Key Relationships
- users.id → user_profiles.id (1:1, auto-created by trigger)
- users.id → projects.user_id (1:many)
- projects.id → datasets.project_id (1:many)
- datasets.id → dashboard_states.dataset_id (1:1)
- teams.id → team_members.team_id (1:many)
- client_access: team_id + user_id + client_name
- project_access: team_id + user_id + project_id

## FILE STRUCTURE
```
api/ (14 files + lib/)
  claude.js, lib/validateSession.js
  auth/: login.js, signup.js, forgot-password.js, reset-password.js, send-code.js, verify-code.js, send-invite.js
  fetch-external.js, google-auth.js, google-sheets-data.js, google-sheets-list.js, google-userinfo.js

src/ (45 files)
  App.jsx, main.jsx, index.css
  components/: AIChartBuilder, AIHub, AIInsights, AIRecommendations, AllChats, AllInsights, AskAI, AuthScreen, AutoCharts, ChatHistory, ClientShareMenu, ColumnTagger, CustomMetrics, Dashboard, DataTable, DraggableGrid, DraggableWidgets, FileUpload, GlobalFilterBar, GoogleSheetsPicker, HomeScreen, KPICards, LogoMark, OnboardingOverlay, PendingInvites, ProjectShareMenu, ProjectWizard, ReportBuilder, ScheduledReports, TeamManager, TierBadge, UpgradePrompt, UserProfile
  context/: AuthContext, DataContext, ProjectContext, ThemeContext, TierContext
  lib/: projectService, supabase, tierConfig
  utils/: aiService, claudeClient, exportService, formatters
```

## OTHER PENDING ITEMS (after security)
- Landing page: pick from 4 options, build and deploy
- Stripe integration: checkout for Pro $19/mo
- Resend domain verification: so real users can sign up
- Error boundaries in React
- Vercel security headers (vercel.json)
